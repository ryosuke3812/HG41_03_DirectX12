#include "SceneField.h"
#include <functional>
#include <stack>
#include <string>
#include <map>
#include <vector>
#include <DirectXMath.h>


HRESULT SceneField::Init()
{
	return S_OK;
}
void SceneField::Uninit()
{
}
void SceneField::Draw()
{

}