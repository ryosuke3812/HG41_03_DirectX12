#ifndef __SCENE_H__
#define __SCENE_H__

#include <Windows.h>

HRESULT InitScene();
void UninitScene();
void DrawScene();

#endif